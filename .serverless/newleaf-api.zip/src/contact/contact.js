"use strict";
exports.__esModule = true;
var aws_sdk_1 = require("aws-sdk");
var ses = new aws_sdk_1.SES();
module.exports.handler = function (event, context, callback) {
    var formData = JSON.parse(event.body);
    sendEmail(formData, function (err, data) {
        var response = {
            statusCode: err ? 500 : 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                message: err ? err.message : data
            })
        };
        callback(null, response);
    });
};
// handler.js
function sendEmail(formData, callback) {
    var emailParams = {
        Source: 'rafaelsouzaf@gmail.com',
        ReplyToAddresses: [formData.reply_to],
        Destination: {
            ToAddresses: ['rafaelsouzaf@gmail.com']
        },
        Message: {
            Body: {
                Text: {
                    Charset: 'UTF-8',
                    Data: formData.message + "\n\nName: " + formData.name + "\nEmail: " + formData.reply_to
                }
            },
            Subject: {
                Charset: 'UTF-8',
                Data: 'newleaf - Contact form'
            }
        }
    };
    ses.sendEmail(emailParams, callback);
}
