"use strict";
exports.__esModule = true;
var aws_sdk_1 = require("aws-sdk");
var dynamoDb = new aws_sdk_1.DynamoDB.DocumentClient();
module.exports.handler = function (event, context, callback) {
    if (event.body === null || event.body === undefined) {
        error(callback, 400, null);
    }
    var body = JSON.parse(event.body);
    if (!body.email || !body.id) {
        error(callback, 400, null);
    }
    var params = {
        TableName: process.env.DYNAMODB_TABLE,
        Key: {
            id: body.id
        },
        UpdateExpression: 'set email = :email, main=:main',
        ConditionExpression: 'main = :num AND attribute_not_exists(email)',
        ExpressionAttributeValues: {
            ':email': body.email,
            ':main': 5,
            ':num': 0
        }
    };
    dynamoDb.update(params, function (err, data) {
        if (err) {
            error(callback, err.code, err.message);
        }
        else {
            answer(callback, 200, {});
        }
    });
};
var answer = function (callback, statusCode, json) {
    delete json.email;
    delete json.main;
    callback(null, {
        statusCode: statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Methods': 'POST,OPTIONS',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify(json)
    });
};
var error = function (callback, statusCode, msg) {
    if (msg) {
        console.error(msg);
    }
    callback(null, {
        statusCode: statusCode
    });
};
