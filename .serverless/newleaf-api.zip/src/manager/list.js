"use strict";
exports.__esModule = true;
var aws_sdk_1 = require("aws-sdk");
var dynamoDb = new aws_sdk_1.DynamoDB.DocumentClient();
module.exports.handler = function (event, context, callback) {
    var _a;
    var email = (_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.email;
    if (!email) {
        error(callback, 400, null);
    }
    var paramsGet = {
        TableName: process.env.DYNAMODB_TABLE,
        IndexName: 'email-main-index',
        KeyConditionExpression: '#email = :email',
        ExpressionAttributeNames: {
            '#email': 'email'
        },
        ExpressionAttributeValues: {
            ':email': email
        }
    };
    dynamoDb.query(paramsGet, function (err, data) {
        if (err) {
            error(callback, err.code, err.message);
        }
        else {
            // if data is Not empty, return data
            if (data.Count > 0) {
                var profiles_1 = [];
                data.Items.forEach(function (item) {
                    var obj = {
                        id: item.id,
                        main: item.main,
                        profile: item.profile,
                        location: item.location
                    };
                    profiles_1.push(obj);
                });
                answer(callback, 200, profiles_1);
            }
            else {
                answer(callback, 200, {});
            }
        }
    });
};
var answer = function (callback, statusCode, json) {
    delete json.email;
    delete json.main;
    callback(null, {
        statusCode: statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Methods': 'GET,OPTIONS',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify(json)
    });
};
var error = function (callback, statusCode, msg) {
    if (msg) {
        console.error(msg);
    }
    callback(null, {
        statusCode: statusCode
    });
};
