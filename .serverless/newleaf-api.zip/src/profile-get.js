"use strict";
exports.__esModule = true;
var aws_sdk_1 = require("aws-sdk");
var dynamoDb = new aws_sdk_1.DynamoDB.DocumentClient();
exports.handler = function (event, context, callback) {
    var id = event.pathParameters.id;
    if (!id) {
        callback(null, {
            statusCode: 400
        });
        return;
    }
    var params = {
        TableName: process.env.DYNAMODB_TABLE,
        Key: {
            id: id
        }
    };
    // fetch todo from the database
    dynamoDb.get(params, function (error, data) {
        // handle potential errors
        if (error) {
            console.error(error);
            callback(null, {
                statusCode: error.statusCode || 501,
                body: "Could not fetch the todo item."
            });
            return;
        }
        delete data.Item.email;
        delete data.Item.main;
        // create a response
        var response = {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Methods": "GET,OPTIONS",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify(data.Item)
        };
        callback(null, response);
    });
};
